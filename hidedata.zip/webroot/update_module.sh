#!/system/bin/sh

# 🚀 已经绑定你专属的 GitHub 释放直链
GH_USER="josefapps"
GH_REPO="hidedata"
ZIP_NAME="hidedata.zip"

# 通过 ghproxy 加速，并强制动态抓取 latest 最新版本
# 自动追踪你发布的最新版本，完美规避大小写和死链接问题
ZIP_URL="https://ghproxy.net/https://github.com/josefapps/hidedata/releases/latest/download/hidedata.zip"


MODID="hidedata"
MODDIR="/data/adb/modules/$MODID"
TMP_ZIP="/data/local/tmp/module_update.zip"
TMP_DIR="/data/local/tmp/module_out"

# 1. 联网检查
if ! ping -c 1 -W 2 223.5.5.5 >/dev/null 2>&1; then
    echo "NETWORK_ERROR"
    exit 1
fi

# 2. 下载远程全量压缩包（结合浏览器 UA + 强制 IPv4，彻底避开网络握手大坑）
curl -4 -L -k -s \
  -A "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36" \
  -H "Sec-Fetch-Mode: navigate" \
  --connect-timeout 15 \
  --retry 3 \
  -o "$TMP_ZIP" "$ZIP_URL"

if [ ! -s "$TMP_ZIP" ]; then
    echo "DOWNLOAD_FAILED"
    exit 1
fi

# 3. 解压到临时提取目录
rm -rf "$TMP_DIR" && mkdir -p "$TMP_DIR"
unzip -q -o "$TMP_ZIP" -d "$TMP_DIR"
if [ $? -ne 0 ]; then
    rm -f "$TMP_ZIP"
    echo "UNZIP_FAILED"
    exit 1
fi

# 4. 安全覆盖处理：防止 .so 被占用导致 Text file busy
if [ -f "$MODDIR/zygisk/arm64-v8a.so" ]; then
    rm -f "$MODDIR/zygisk/arm64-v8a.so"
fi

# 开始执行全量覆盖
cp -rf "$TMP_DIR"/* "$MODDIR/"

# 5. 关键步骤：修复由于解压导致的模块文件及脚本权限丢失与系统安全上下文
chown -R root:root "$MODDIR"
find "$MODDIR" -type d -exec chmod 755 {} \;
find "$MODDIR" -type f -exec chmod 644 {} \;

# 为所有需要执行权限的核心脚本恢复可执行权限 (755)
[ -d "$MODDIR/sh" ] && chmod 755 "$MODDIR/sh"/*
[ -f "$MODDIR/service.sh" ] && chmod 755 "$MODDIR/service.sh"
[ -f "$MODDIR/uninstall.sh" ] && chmod 755 "$MODDIR/uninstall.sh"
[ -f "$MODDIR/webroot/update_module.sh" ] && chmod 755 "$MODDIR/webroot/update_module.sh"
[ -f "$MODDIR/webroot/script.sh" ] && chmod 755 "$MODDIR/webroot/script.sh"
[ -f "$MODDIR/webroot/script2.sh" ] && chmod 755 "$MODDIR/webroot/script2.sh"
[ -f "$MODDIR/webroot/script3.sh" ] && chmod 755 "$MODDIR/webroot/script3.sh"

# 刷新 Android 系统的 SELinux 权限标签防止拦截
restorecon -R "$MODDIR"

# 6. 环境收尾清理
rm -f "$TMP_ZIP"
rm -rf "$TMP_DIR"

# 完美结束，告知前端
echo "SUCCESS"
