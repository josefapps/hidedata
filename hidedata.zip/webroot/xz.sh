#!/system/bin/sh

GH_USER="josefapps"
GH_REPO="hidedata"
ZIP_NAME="hidedata.zip"
ZIP_URL="https://ghproxy.net/https://raw.githubusercontent.com/$GH_USER/$GH_REPO/main/$ZIP_NAME?t=$(date +%s)"

MODID="hidedata"
MODDIR="/data/adb/modules/$MODID"
TMP_ZIP="/data/local/tmp/module_update.zip"
TMP_DIR="/data/local/tmp/module_out"
if ! ping -c 1 -W 2 223.5.5.5 >/dev/null 2>&1; then
    echo "NETWORK_ERROR"
    exit 1
fi
curl -4 -L -k -s \
  -A "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36" \
  -H "Sec-Fetch-Mode: navigate" \
  -H "Cache-Control: no-cache" \
  -H "Pragma: no-cache" \
  --connect-timeout 15 \
  --retry 3 \
  -o "$TMP_ZIP" "$ZIP_URL"

if [ ! -s "$TMP_ZIP" ]; then
    echo "DOWNLOAD_FAILED"
    exit 1
fi
rm -rf "$TMP_DIR" && mkdir -p "$TMP_DIR"
unzip -q -o "$TMP_ZIP" -d "$TMP_DIR"
if [ $? -ne 0 ]; then
    rm -f "$TMP_ZIP"
    echo "UNZIP_FAILED"
    exit 1
fi
cp -rf "$TMP_DIR"/* "$MODDIR/"
rm -f "$TMP_ZIP"
rm -rf "$TMP_DIR"

echo "SUCCESS"
