#!/system/bin/sh
TS="/data/adb/modules/tricky_store"
if [ -L "$TS/webroot" ]; then
    rm -f "$TS/webroot"
fi
